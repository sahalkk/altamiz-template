<?php
/**
 * Contact Form Handler with SMTP support for GoDaddy
 * 
 * CONFIGURATION:
 * This script uses GoDaddy's SMTP relay server which works on shared hosting
 * 
 * GoDaddy SMTP Settings:
 * - Server: relay-hosting.secureserver.net
 * - Port: 25
 * - Authentication: Not required
 * - Daily limit: 1000 emails
 * 
 * IMPORTANT: The sender email must be from your domain (e.g., info@yourdomain.com)
 */

// Configuration
$receiving_email = "msahalkk357@gmail.com"; // Where to receive form submissions

// GoDaddy SMTP Configuration
$smtp_host = "relay-hosting.secureserver.net";
$smtp_port = 25;
$smtp_timeout = 30;

// Sender email (must be from your domain registered with GoDaddy)
// IMPORTANT: Use an email that exists on your GoDaddy account or create one in cPanel
$sender_email = "info@tmz-c.com"; // CHANGE THIS to an email you have on GoDaddy

/**
 * Send email via SMTP (using GoDaddy relay)
 */
function sendEmailSMTP($to, $subject, $body, $headers, $from) {
    global $smtp_host, $smtp_port, $smtp_timeout;
    
    try {
        // Connect to SMTP server
        $smtp = @fsockopen($smtp_host, $smtp_port, $errno, $errstr, $smtp_timeout);
        
        if (!$smtp) {
            error_log("SMTP connection failed: $errstr ($errno)");
            return false;
        }
        
        // Set socket timeout
        stream_set_timeout($smtp, $smtp_timeout);
        
        // Read server response
        $response = fgets($smtp, 515);
        error_log("SMTP Server Reply: $response");
        
        if (substr($response, 0, 3) !== '220') {
            error_log("SMTP initial connection failed: $response");
            fclose($smtp);
            return false;
        }
        
        // Send HELO command
        $server_name = isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost';
        fputs($smtp, "HELO " . $server_name . "\r\n");
        $response = fgets($smtp, 515);
        error_log("SMTP HELO Response: $response");
        
        // Send MAIL FROM command
        fputs($smtp, "MAIL FROM:<" . $from . ">\r\n");
        $response = fgets($smtp, 515);
        error_log("SMTP MAIL FROM Response: $response");
        
        // Send RCPT TO command
        fputs($smtp, "RCPT TO:<" . $to . ">\r\n");
        $response = fgets($smtp, 515);
        error_log("SMTP RCPT TO Response: $response");
        
        // Send DATA command
        fputs($smtp, "DATA\r\n");
        $response = fgets($smtp, 515);
        error_log("SMTP DATA Response: $response");
        
        // Send email headers and body
        // Note: To: header needs to be in the email content
        $email_content = $headers . "\r\nTo: " . $to . "\r\n\r\n" . $body . "\r\n.\r\n";
        fputs($smtp, $email_content);
        $response = fgets($smtp, 515);
        error_log("SMTP Message Sent Response: $response");
        
        // Check if message was accepted
        if (strpos($response, '250') === false && strpos($response, '200') === false) {
            error_log("SMTP message not accepted: $response");
            fputs($smtp, "QUIT\r\n");
            fclose($smtp);
            return false;
        }
        
        // Close connection
        fputs($smtp, "QUIT\r\n");
        fgets($smtp, 515);
        fclose($smtp);
        
        return true;
        
    } catch (Exception $e) {
        error_log("SMTP error: " . $e->getMessage());
        if (isset($smtp)) {
            @fclose($smtp);
        }
        return false;
    }
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $name = isset($_POST["name"]) ? htmlspecialchars(trim($_POST["name"])) : "";
    // Check for both "email" and "mail" field names for compatibility
    $email = isset($_POST["email"]) ? htmlspecialchars(trim($_POST["email"])) : (isset($_POST["mail"]) ? htmlspecialchars(trim($_POST["mail"])) : "");
    $phone = isset($_POST["phone"]) ? htmlspecialchars(trim($_POST["phone"])) : "";
    $subject = isset($_POST["subject"]) ? htmlspecialchars(trim($_POST["subject"])) : "";
    $message = isset($_POST["message"]) ? htmlspecialchars(trim($_POST["message"])) : "";
    
    // Debug logging (remove in production)
    error_log("Contact form submission - POST data: " . print_r($_POST, true));
    
    // Validation
    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode(array("success" => false, "message" => "Please fill in all required fields."));
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(array("success" => false, "message" => "Invalid email address."));
        exit;
    }
    
    // Email setup
    $to = $receiving_email;
    $email_subject = "Contact Submission - " . ($subject ? $subject : "Al Tameez Website");
    $email_body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            table { border-collapse: collapse; width: 100%; }
            td, th { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h2>New Contact Form Submission</h2>
        <table>
            <tr>
                <td style='text-align: right; font-weight: bold;'>Name:</td>
                <th style='text-align: left;'>" . $name . "</th>
            </tr>
            <tr>
                <td style='text-align: right; font-weight: bold;'>Email:</td>
                <th style='text-align: left;'>" . $email . "</th>
            </tr>
            <tr>
                <td style='text-align: right; font-weight: bold;'>Phone:</td>
                <th style='text-align: left;'>" . $phone . "</th>
            </tr>
            <tr>
                <td style='text-align: right; font-weight: bold;'>Subject:</td>
                <th style='text-align: left;'>" . ($subject ? $subject : "Not specified") . "</th>
            </tr>
            <tr>
                <td style='text-align: right; font-weight: bold; vertical-align: top;'>Message:</td>
                <th style='text-align: left;'>" . nl2br($message) . "</th>
            </tr>
        </table>
    </body>
    </html>
    ";
    
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: Al Tameez Website <" . $sender_email . ">" . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
    $headers .= "Subject: " . $email_subject . "\r\n";
    
    // Save submission to file as backup
    $submission_data = array(
        'timestamp' => date('Y-m-d H:i:s'),
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'subject' => $subject,
        'message' => $message
    );
    file_put_contents('contact_submissions.txt', json_encode($submission_data) . "\n", FILE_APPEND);
    
    // Try to send email via SMTP first, fall back to mail() if that fails
    error_log("Attempting to send email via SMTP...");
    $mail_sent = sendEmailSMTP($receiving_email, $email_subject, $email_body, $headers, $sender_email);
    
    // If SMTP fails, try regular mail() as fallback
    if (!$mail_sent) {
        error_log("SMTP failed, trying regular mail()...");
        $mail_sent = @mail($receiving_email, $email_subject, $email_body, $headers);
    }
    
    // Log email attempt
    error_log("Email attempt - To: $receiving_email, From: $sender_email, Sent: " . ($mail_sent ? "Yes" : "No"));
    
    if ($mail_sent) {
        echo json_encode(array("success" => true, "message" => "Thank you! We will contact you soon."));
    } else {
        $error = error_get_last();
        error_log("Mail error: " . print_r($error, true));
        // Return success anyway since we saved the data to file
        echo json_encode(array("success" => true, "message" => "Thank you! We have received your message and will contact you soon."));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}
?>


